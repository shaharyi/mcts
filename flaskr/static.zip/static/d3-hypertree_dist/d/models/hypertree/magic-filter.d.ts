import { IUnitDisk } from '../../components/unitdisk/unitdisk';
import { TransformationCache } from '../transformation/hyperbolic-transformation';
export declare function cacheUpdate(ud: IUnitDisk, cache: TransformationCache): void;
