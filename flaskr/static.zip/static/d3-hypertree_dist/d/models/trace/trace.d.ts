import { C } from '../transformation/hyperbolic-math';
export interface Trace {
    id: string;
    points: C[];
}
