import { UnitDisk } from './unitdisk';
export declare const navBgNodeR = 0.012;
export declare const navBackgroundLayers: ((v: any, ud: UnitDisk) => any)[];
