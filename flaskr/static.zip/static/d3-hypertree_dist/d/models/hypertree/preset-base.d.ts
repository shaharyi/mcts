export declare const presets: {
    [key: string]: () => any;
};
